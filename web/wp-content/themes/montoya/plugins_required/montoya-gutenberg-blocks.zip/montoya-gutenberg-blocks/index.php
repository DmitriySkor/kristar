<?php

/*
Plugin Name: Montoya Gutenberg Blocks
Plugin URI: https://clapat.com/
Description: Gutenberg editor blocks for Montoya WordPress Theme
Version: 1.1
Author: ClaPat
Author URI: https://clapat.com/
*/

defined( 'ABSPATH' ) || exit;

include 'blocks/index.php';
